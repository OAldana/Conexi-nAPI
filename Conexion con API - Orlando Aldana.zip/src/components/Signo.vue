<template>
  <div>
    <div>
      <h1>Buscar Signo</h1>
      <div class="small-container">
        <h4>Ingrese el Signo a buscar</h4>
        <div>
          <input class="form-field" type="text" v-model="sign" />
          <button @click="buscar" class="btn">Buscar</button>
        </div>
      </div>
      <div class="small-container">
        <h4>Los astros informan:</h4>
        <div class="player">
          <div>Signo:</div>
          <div>{{ sign }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Para el día:</div>
          <div>{{ datos.current_date }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Compatible con:</div>
          <div>{{ datos.compatibility }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Numero de la suerte:</div>
          <div>{{ datos.lucky_number }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Hora de la suerte:</div>
          <div>{{ datos.lucky_time }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Color de la suerte:</div>
          <div>{{ datos.color }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Rango de Fecha:</div>
          <div>{{ datos.date_range }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Estado de animo:</div>
          <div>{{ datos.mood }}</div>
          <div class="line" style="flex-basis: 100%" />
          <div>Descripción:</div>
          <div>{{ datos.description }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
const URL = "https://aztro.sameerkumar.website";
export default {
  data() {
    return {
      sign: "",
      datos: {},
    };
  },

  methods: {
    buscar() {
      axios
        .post(URL + "/?sign=" + this.sign + "&day=today")
        .then((res) => (this.datos = res.data));
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.form-field {
  padding: 7px;
  border-radius: 3px;
  border: 1px solid;
}
.btn {
  margin-left: 5px;
  padding: 7px;
  background-color: #100c45;
  border: none;
  border-radius: 3px;
  transition: all 0.2s;
  color: white;
}
.btn:hover {
  background-color: #100c45;
}
.player {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;
  align-items: center;
  row-gap: 10px;
  width: 500px;
  padding: 30px;
  background-color: #100c45;
  border-radius: 20px;
  color: white;
}
.line {
  border: 1px solid rgb(255, 255, 255);
}

h1, h4{
  color:black
}
</style>
