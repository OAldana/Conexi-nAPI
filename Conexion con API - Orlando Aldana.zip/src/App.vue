<template>
  <Signo />
</template>

<script>
import SignoVue from "./components/Signo.vue";
export default {
  name: "App",
  components: {
    Signo: SignoVue,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
